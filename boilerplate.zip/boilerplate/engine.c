/*
 * engine.c - Supervised Multi-Container Runtime (User Space)
 *
 * Intentionally partial starter:
 *   - command-line shape is defined
 *   - key runtime data structures are defined
 *   - bounded-buffer skeleton is defined
 *   - supervisor / client split is outlined
 *
 * Students are expected to design:
 *   - the control-plane IPC implementation
 *   - container lifecycle and metadata synchronization
 *   - clone + namespace setup for each container
 *   - producer/consumer behavior for log buffering
 *   - signal handling and graceful shutdown
 */

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mount.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#include "monitor_ioctl.h"

#define STACK_SIZE (1024 * 1024)
#define CONTAINER_ID_LEN 32
#define CONTROL_PATH "/tmp/mini_runtime.sock"
#define LOG_DIR "logs"
#define CONTROL_MESSAGE_LEN 256
#define CHILD_COMMAND_LEN 256
#define LOG_CHUNK_SIZE 4096
#define LOG_BUFFER_CAPACITY 16
#define DEFAULT_SOFT_LIMIT (40UL << 20)
#define DEFAULT_HARD_LIMIT (64UL << 20)

typedef enum {
    CMD_SUPERVISOR = 0,
    CMD_START,
    CMD_RUN,
    CMD_PS,
    CMD_LOGS,
    CMD_STOP
} command_kind_t;

typedef enum {
    CONTAINER_STARTING = 0,
    CONTAINER_RUNNING,
    CONTAINER_STOPPED,
    CONTAINER_KILLED,
    CONTAINER_EXITED
} container_state_t;

typedef struct container_record {
    char id[CONTAINER_ID_LEN];
    pid_t host_pid;
    time_t started_at;
    container_state_t state;
    unsigned long soft_limit_bytes;
    unsigned long hard_limit_bytes;
    int stop_requested;
    int waiter_fd;
    int exit_code;
    int exit_signal;
    char log_path[PATH_MAX];
    struct container_record *next;
} container_record_t;

typedef struct {
    char container_id[CONTAINER_ID_LEN];
    size_t length;
    char data[LOG_CHUNK_SIZE];
} log_item_t;

typedef struct {
    log_item_t items[LOG_BUFFER_CAPACITY];
    size_t head;
    size_t tail;
    size_t count;
    int shutting_down;
    pthread_mutex_t mutex;
    pthread_cond_t not_empty;
    pthread_cond_t not_full;
} bounded_buffer_t;

typedef struct {
    command_kind_t kind;
    char container_id[CONTAINER_ID_LEN];
    char rootfs[PATH_MAX];
    char command[CHILD_COMMAND_LEN];
    unsigned long soft_limit_bytes;
    unsigned long hard_limit_bytes;
    int nice_value;
} control_request_t;

typedef struct {
    int status;
    char message[CONTROL_MESSAGE_LEN];
} control_response_t;

typedef struct {
    char id[CONTAINER_ID_LEN];
    char rootfs[PATH_MAX];
    char command[CHILD_COMMAND_LEN];
    int nice_value;
    int log_write_fd;
} child_config_t;

typedef struct {
    int server_fd;
    int monitor_fd;
    int should_stop;
    pthread_t logger_thread;
    bounded_buffer_t log_buffer;
    pthread_mutex_t metadata_lock;
    container_record_t *containers;
} supervisor_ctx_t;

static void usage(const char *prog)
{
    fprintf(stderr,
            "Usage:\n"
            "  %s supervisor <base-rootfs>\n"
            "  %s start <id> <container-rootfs> <command> [--soft-mib N] [--hard-mib N] [--nice N]\n"
            "  %s run <id> <container-rootfs> <command> [--soft-mib N] [--hard-mib N] [--nice N]\n"
            "  %s ps\n"
            "  %s logs <id>\n"
            "  %s stop <id>\n",
            prog, prog, prog, prog, prog, prog);
}

static int parse_mib_flag(const char *flag,
                          const char *value,
                          unsigned long *target_bytes)
{
    char *end = NULL;
    unsigned long mib;

    errno = 0;
    mib = strtoul(value, &end, 10);
    if (errno != 0 || end == value || *end != '\0') {
        fprintf(stderr, "Invalid value for %s: %s\n", flag, value);
        return -1;
    }

    if (mib > ULONG_MAX / (1UL << 20)) {
        fprintf(stderr, "Value for %s is too large: %s\n", flag, value);
        return -1;
    }

    *target_bytes = mib * (1UL << 20);
    return 0;
}

static int parse_optional_flags(control_request_t *req,
                                int argc,
                                char *argv[],
                                int start_index)
{
    int i;

    for (i = start_index; i < argc; i += 2) {
        char *end = NULL;
        long nice_value;

        if (i + 1 >= argc) {
            fprintf(stderr, "Missing value for option: %s\n", argv[i]);
            return -1;
        }

        if (strcmp(argv[i], "--soft-mib") == 0) {
            if (parse_mib_flag("--soft-mib", argv[i + 1], &req->soft_limit_bytes) != 0)
                return -1;
            continue;
        }

        if (strcmp(argv[i], "--hard-mib") == 0) {
            if (parse_mib_flag("--hard-mib", argv[i + 1], &req->hard_limit_bytes) != 0)
                return -1;
            continue;
        }

        if (strcmp(argv[i], "--nice") == 0) {
            errno = 0;
            nice_value = strtol(argv[i + 1], &end, 10);
            if (errno != 0 || end == argv[i + 1] || *end != '\0' ||
                nice_value < -20 || nice_value > 19) {
                fprintf(stderr,
                        "Invalid value for --nice (expected -20..19): %s\n",
                        argv[i + 1]);
                return -1;
            }
            req->nice_value = (int)nice_value;
            continue;
        }

        fprintf(stderr, "Unknown option: %s\n", argv[i]);
        return -1;
    }

    if (req->soft_limit_bytes > req->hard_limit_bytes) {
        fprintf(stderr, "Invalid limits: soft limit cannot exceed hard limit\n");
        return -1;
    }

    return 0;
}

static const char *state_to_string(container_state_t state)
{
    switch (state) {
    case CONTAINER_STARTING:
        return "starting";
    case CONTAINER_RUNNING:
        return "running";
    case CONTAINER_STOPPED:
        return "stopped";
    case CONTAINER_KILLED:
        return "killed";
    case CONTAINER_EXITED:
        return "exited";
    default:
        return "unknown";
    }
}

static int bounded_buffer_init(bounded_buffer_t *buffer)
{
    int rc;

    memset(buffer, 0, sizeof(*buffer));

    rc = pthread_mutex_init(&buffer->mutex, NULL);
    if (rc != 0)
        return rc;

    rc = pthread_cond_init(&buffer->not_empty, NULL);
    if (rc != 0) {
        pthread_mutex_destroy(&buffer->mutex);
        return rc;
    }

    rc = pthread_cond_init(&buffer->not_full, NULL);
    if (rc != 0) {
        pthread_cond_destroy(&buffer->not_empty);
        pthread_mutex_destroy(&buffer->mutex);
        return rc;
    }

    return 0;
}

static void bounded_buffer_destroy(bounded_buffer_t *buffer)
{
    pthread_cond_destroy(&buffer->not_full);
    pthread_cond_destroy(&buffer->not_empty);
    pthread_mutex_destroy(&buffer->mutex);
}

static void bounded_buffer_begin_shutdown(bounded_buffer_t *buffer)
{
    pthread_mutex_lock(&buffer->mutex);
    buffer->shutting_down = 1;
    pthread_cond_broadcast(&buffer->not_empty);
    pthread_cond_broadcast(&buffer->not_full);
    pthread_mutex_unlock(&buffer->mutex);
}

/*
 * Implement producer-side insertion into the bounded buffer.
 */
int bounded_buffer_push(bounded_buffer_t *buffer, const log_item_t *item)
{
    pthread_mutex_lock(&buffer->mutex);

    while (buffer->count == LOG_BUFFER_CAPACITY && !buffer->shutting_down) {
        pthread_cond_wait(&buffer->not_full, &buffer->mutex);
    }

    if (buffer->shutting_down) {
        pthread_mutex_unlock(&buffer->mutex);
        return -1;
    }

    buffer->items[buffer->tail] = *item;
    buffer->tail = (buffer->tail + 1) % LOG_BUFFER_CAPACITY;
    buffer->count++;

    pthread_cond_signal(&buffer->not_empty);
    pthread_mutex_unlock(&buffer->mutex);

    return 0;
}

/*
 * Implement consumer-side removal from the bounded buffer.
 */
int bounded_buffer_pop(bounded_buffer_t *buffer, log_item_t *item)
{
    pthread_mutex_lock(&buffer->mutex);

    while (buffer->count == 0 && !buffer->shutting_down) {
        pthread_cond_wait(&buffer->not_empty, &buffer->mutex);
    }

    if (buffer->count == 0 && buffer->shutting_down) {
        pthread_mutex_unlock(&buffer->mutex);
        return -1;
    }

    *item = buffer->items[buffer->head];
    buffer->head = (buffer->head + 1) % LOG_BUFFER_CAPACITY;
    buffer->count--;

    pthread_cond_signal(&buffer->not_full);
    pthread_mutex_unlock(&buffer->mutex);

    return 0;
}

/*
 * Implement the logging consumer thread.
 */
void *logging_thread(void *arg)
{
    supervisor_ctx_t *ctx = (supervisor_ctx_t *)arg;
    log_item_t item;

    /*
     * Keep popping until the buffer is empty AND shutting_down is set.
     * bounded_buffer_pop returns -1 only when buffer is empty AND shutting_down.
     */
    while (bounded_buffer_pop(&ctx->log_buffer, &item) == 0) {
        char log_file_path[PATH_MAX];
        snprintf(log_file_path, sizeof(log_file_path), "%s/%s.log", LOG_DIR, item.container_id);

        int fd = open(log_file_path, O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (fd < 0) {
            perror("open log file");
            continue;
        }

        if (write(fd, item.data, item.length) < 0) {
            perror("write log file");
        }
        close(fd);
    }

    return NULL;
}

int register_with_monitor(int monitor_fd,
                          const char *container_id,
                          pid_t host_pid,
                          unsigned long soft_limit_bytes,
                          unsigned long hard_limit_bytes)
{
    struct monitor_request req;

    memset(&req, 0, sizeof(req));
    req.pid = host_pid;
    req.soft_limit_bytes = soft_limit_bytes;
    req.hard_limit_bytes = hard_limit_bytes;
    strncpy(req.container_id, container_id, sizeof(req.container_id) - 1);

    if (ioctl(monitor_fd, MONITOR_REGISTER, &req) < 0)
        return -1;

    return 0;
}

int unregister_from_monitor(int monitor_fd, const char *container_id, pid_t host_pid)
{
    struct monitor_request req;

    memset(&req, 0, sizeof(req));
    req.pid = host_pid;
    strncpy(req.container_id, container_id, sizeof(req.container_id) - 1);

    if (ioctl(monitor_fd, MONITOR_UNREGISTER, &req) < 0)
        return -1;

    return 0;
}

/*
 * Implement the clone child entrypoint.
 */
int child_fn(void *arg)
{
    child_config_t *config = (child_config_t *)arg;

    /* UTS namespace: hostname */
    if (sethostname(config->id, strlen(config->id)) < 0) {
        perror("sethostname");
        return 1;
    }

    /* Mount namespace: isolate rootfs */
    if (chroot(config->rootfs) < 0) {
        perror("chroot");
        return 1;
    }
    if (chdir("/") < 0) {
        perror("chdir /");
        return 1;
    }

    /* Mount /proc for tools like ps */
    if (mount("proc", "/proc", "proc", 0, NULL) < 0) {
        perror("mount /proc");
        return 1;
    }

    /* Nice value */
    if (setpriority(PRIO_PROCESS, 0, config->nice_value) < 0) {
        perror("setpriority");
        /* Non-fatal: continue */
    }

    /* Redirect stdout/stderr to the supervisor logging path */
    if (dup2(config->log_write_fd, STDOUT_FILENO) < 0 ||
        dup2(config->log_write_fd, STDERR_FILENO) < 0) {
        perror("dup2");
        return 1;
    }
    close(config->log_write_fd);

    /* Execute the command */
    char *argv[] = {"/bin/sh", "-c", config->command, NULL};
    execv("/bin/sh", argv);

    perror("execv");
    return 1;
}

static void *producer_thread(void *arg)
{
    typedef struct {
        int read_fd;
        char id[CONTAINER_ID_LEN];
        bounded_buffer_t *buffer;
    } prod_ctx_t;

    prod_ctx_t *ctx = (prod_ctx_t *)arg;
    log_item_t item;
    ssize_t n;

    strncpy(item.container_id, ctx->id, sizeof(item.container_id) - 1);

    while ((n = read(ctx->read_fd, item.data, sizeof(item.data))) > 0) {
        item.length = (size_t)n;
        if (bounded_buffer_push(ctx->buffer, &item) != 0) break;
    }

    close(ctx->read_fd);
    free(ctx);
    return NULL;
}

static int launch_container(supervisor_ctx_t *ctx, control_request_t *req, control_response_t *resp)
{
    pthread_mutex_lock(&ctx->metadata_lock);
    container_record_t *curr = ctx->containers;
    while (curr) {
        if (strcmp(curr->id, req->container_id) == 0 && curr->state == CONTAINER_RUNNING) {
            resp->status = -1;
            snprintf(resp->message, sizeof(resp->message), "Container ID %s already in use", req->container_id);
            pthread_mutex_unlock(&ctx->metadata_lock);
            return -1;
        }
        curr = curr->next;
    }
    pthread_mutex_unlock(&ctx->metadata_lock);

    int pipefd[2];
    if (pipe(pipefd) < 0) {
        perror("pipe");
        return -1;
    }

    child_config_t *config = malloc(sizeof(child_config_t));
    strncpy(config->id, req->container_id, sizeof(config->id) - 1);
    strncpy(config->rootfs, req->rootfs, sizeof(config->rootfs) - 1);
    strncpy(config->command, req->command, sizeof(config->command) - 1);
    config->nice_value = req->nice_value;
    config->log_write_fd = pipefd[1];

    char *stack = malloc(STACK_SIZE);
    pid_t child_pid = clone(child_fn, stack + STACK_SIZE,
                            CLONE_NEWPID | CLONE_NEWUTS | CLONE_NEWNS | SIGCHLD, config);

    if (child_pid < 0) {
        perror("clone");
        close(pipefd[0]);
        close(pipefd[1]);
        free(stack);
        free(config);
        return -1;
    }

    close(pipefd[1]); // Close write end in parent

    /* Register with kernel monitor */
    if (ctx->monitor_fd != -1) {
        register_with_monitor(ctx->monitor_fd, req->container_id, child_pid,
                               req->soft_limit_bytes, req->hard_limit_bytes);
    }

    /* Start producer thread for this container */
    typedef struct {
        int read_fd;
        char id[CONTAINER_ID_LEN];
        bounded_buffer_t *buffer;
    } prod_ctx_t;
    prod_ctx_t *p_ctx = malloc(sizeof(prod_ctx_t));
    p_ctx->read_fd = pipefd[0];
    strncpy(p_ctx->id, req->container_id, sizeof(p_ctx->id) - 1);
    p_ctx->buffer = &ctx->log_buffer;

    pthread_t p_thread;
    pthread_create(&p_thread, NULL, producer_thread, p_ctx);
    pthread_detach(p_thread);

    /* Update metadata */
    container_record_t *record = malloc(sizeof(container_record_t));
    memset(record, 0, sizeof(*record));
    strncpy(record->id, req->container_id, sizeof(record->id) - 1);
    record->host_pid = child_pid;
    record->started_at = time(NULL);
    record->state = CONTAINER_RUNNING;
    record->soft_limit_bytes = req->soft_limit_bytes;
    record->hard_limit_bytes = req->hard_limit_bytes;
    record->waiter_fd = -1;
    snprintf(record->log_path, sizeof(record->log_path), "%s/%s.log", LOG_DIR, req->container_id);

    pthread_mutex_lock(&ctx->metadata_lock);
    record->next = ctx->containers;
    ctx->containers = record;
    pthread_mutex_unlock(&ctx->metadata_lock);

    snprintf(resp->message, sizeof(resp->message), "Container %s started (PID %d)", req->container_id, child_pid);
    return 0;
}

static supervisor_ctx_t *g_ctx = NULL;

static void handle_request(supervisor_ctx_t *ctx, int client_fd)
{
    control_request_t req;
    control_response_t resp;

    if (read(client_fd, &req, sizeof(req)) != sizeof(req)) {
        perror("read request");
        close(client_fd);
        return;
    }

    memset(&resp, 0, sizeof(resp));
    resp.status = 0;

    switch (req.kind) {
    case CMD_START:
        launch_container(ctx, &req, &resp);
        if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
        close(client_fd);
        break;
    case CMD_RUN: {
        if (launch_container(ctx, &req, &resp) == 0) {
            pthread_mutex_lock(&ctx->metadata_lock);
            container_record_t *curr = ctx->containers;
            while (curr) {
                if (strcmp(curr->id, req.container_id) == 0 && curr->state == CONTAINER_RUNNING) {
                    curr->waiter_fd = client_fd;
                    break;
                }
                curr = curr->next;
            }
            pthread_mutex_unlock(&ctx->metadata_lock);
        } else {
            if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
            close(client_fd);
        }
        break;
    }
    case CMD_PS: {
        pthread_mutex_lock(&ctx->metadata_lock);
        container_record_t *curr = ctx->containers;
        char *ptr = resp.message;
        size_t left = sizeof(resp.message) - 1;
        int n = snprintf(ptr, left, "%-10s %-8s %-10s %-10s\n", "ID", "PID", "STATE", "LIMITS(S/H)");
        if (n > 0) { ptr += n; left -= n; }
        while (curr && left > 0) {
            n = snprintf(ptr, left, "%-10s %-8d %-10s %lu/%lu MiB\n",
                         curr->id, curr->host_pid, state_to_string(curr->state),
                         curr->soft_limit_bytes >> 20, curr->hard_limit_bytes >> 20);
            if (n > 0) { ptr += n; left -= n; }
            curr = curr->next;
        }
        pthread_mutex_unlock(&ctx->metadata_lock);
        if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
        close(client_fd);
        break;
    }
    case CMD_LOGS: {
        char log_path[PATH_MAX];
        snprintf(log_path, sizeof(log_path), "%s/%s.log", LOG_DIR, req.container_id);
        int fd = open(log_path, O_RDONLY);
        if (fd < 0) {
            snprintf(resp.message, sizeof(resp.message), "No logs found for %s", req.container_id);
        } else {
            off_t size = lseek(fd, 0, SEEK_END);
            off_t offset = (size > (off_t)sizeof(resp.message) - 1) ? size - (sizeof(resp.message) - 1) : 0;
            lseek(fd, offset, SEEK_SET);
            read(fd, resp.message, sizeof(resp.message) - 1);
            close(fd);
        }
        if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
        close(client_fd);
        break;
    }
    case CMD_STOP: {
        pthread_mutex_lock(&ctx->metadata_lock);
        container_record_t *curr = ctx->containers;
        while (curr) {
            if (strcmp(curr->id, req.container_id) == 0 && curr->state == CONTAINER_RUNNING) {
                curr->stop_requested = 1;
                kill(curr->host_pid, SIGTERM);
                snprintf(resp.message, sizeof(resp.message), "Stop signal sent to %s", req.container_id);
                break;
            }
            curr = curr->next;
        }
        if (!curr) snprintf(resp.message, sizeof(resp.message), "Container %s not running", req.container_id);
        pthread_mutex_unlock(&ctx->metadata_lock);
        if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
        close(client_fd);
        break;
    }
    default:
        resp.status = -1;
        snprintf(resp.message, sizeof(resp.message), "Unknown command");
        if (write(client_fd, &resp, sizeof(resp)) != sizeof(resp)) perror("write response");
        close(client_fd);
        break;
    }
}

static void handle_sigchld(int sig)
{
    (void)sig;
    int status;
    pid_t pid;

    while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
        if (g_ctx) {
            pthread_mutex_lock(&g_ctx->metadata_lock);
            container_record_t *curr = g_ctx->containers;
            while (curr) {
                if (curr->host_pid == pid) {
                    if (WIFEXITED(status)) {
                        curr->exit_code = WEXITSTATUS(status);
                        curr->state = curr->stop_requested ? CONTAINER_STOPPED : CONTAINER_EXITED;
                    } else if (WIFSIGNALED(status)) {
                        curr->exit_signal = WTERMSIG(status);
                        if (curr->exit_signal == SIGKILL && !curr->stop_requested) {
                            curr->state = CONTAINER_KILLED;
                        } else {
                            curr->state = CONTAINER_STOPPED;
                        }
                    }

                    if (curr->waiter_fd != -1) {
                        control_response_t wait_resp;
                        memset(&wait_resp, 0, sizeof(wait_resp));
                        wait_resp.status = 0;
                        snprintf(wait_resp.message, sizeof(wait_resp.message), "Container %s exited", curr->id);
                        write(curr->waiter_fd, &wait_resp, sizeof(wait_resp));
                        close(curr->waiter_fd);
                        curr->waiter_fd = -1;
                    }

                    if (g_ctx->monitor_fd != -1) {
                        unregister_from_monitor(g_ctx->monitor_fd, curr->id, curr->host_pid);
                    }
                    break;
                }
                curr = curr->next;
            }
            pthread_mutex_unlock(&g_ctx->metadata_lock);
        }
    }
}

static void handle_signal(int sig)
{
    if (g_ctx) {
        g_ctx->should_stop = 1;
        if (g_ctx->server_fd != -1) {
            close(g_ctx->server_fd);
            g_ctx->server_fd = -1;
        }
    }
}

static int run_supervisor(const char *rootfs)
{
    supervisor_ctx_t ctx;
    struct sockaddr_un addr;
    int rc;

    memset(&ctx, 0, sizeof(ctx));
    ctx.server_fd = -1;
    ctx.monitor_fd = open("/dev/container_monitor", O_RDWR);
    if (ctx.monitor_fd < 0) {
        perror("open /dev/container_monitor");
    }

    rc = pthread_mutex_init(&ctx.metadata_lock, NULL);
    if (rc != 0) {
        errno = rc;
        perror("pthread_mutex_init");
        return 1;
    }

    rc = bounded_buffer_init(&ctx.log_buffer);
    if (rc != 0) {
        errno = rc;
        perror("bounded_buffer_init");
        pthread_mutex_destroy(&ctx.metadata_lock);
        return 1;
    }

    mkdir(LOG_DIR, 0755);

    ctx.server_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (ctx.server_fd < 0) {
        perror("socket");
        goto cleanup;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, CONTROL_PATH, sizeof(addr.sun_path) - 1);
    unlink(CONTROL_PATH);

    if (bind(ctx.server_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        goto cleanup;
    }

    if (listen(ctx.server_fd, 5) < 0) {
        perror("listen");
        goto cleanup;
    }

    g_ctx = &ctx;
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    
    struct sigaction sa;
    sa.sa_handler = handle_sigchld;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa, NULL);

    if (pthread_create(&ctx.logger_thread, NULL, logging_thread, &ctx) != 0) {
        perror("pthread_create (logger)");
        goto cleanup;
    }

    printf("Supervisor started with base rootfs: %s\n", rootfs);
    printf("Listening on %s\n", CONTROL_PATH);

    while (!ctx.should_stop) {
        int client_fd = accept(ctx.server_fd, NULL, NULL);
        if (client_fd < 0) {
            if (ctx.should_stop) break;
            perror("accept");
            continue;
        }
        handle_request(&ctx, client_fd);
    }

    printf("Supervisor shutting down...\n");

cleanup:
    /* Kill all running containers */
    pthread_mutex_lock(&ctx.metadata_lock);
    container_record_t *it = ctx.containers;
    while (it) {
        if (it->state == CONTAINER_RUNNING) {
            it->stop_requested = 1;
            kill(it->host_pid, SIGTERM);
        }
        it = it->next;
    }
    pthread_mutex_unlock(&ctx.metadata_lock);
    /* Brief wait for containers to exit and be reaped by SIGCHLD handler */
    sleep(1);

    bounded_buffer_begin_shutdown(&ctx.log_buffer);
    if (ctx.logger_thread) {
        pthread_join(ctx.logger_thread, NULL);
    }
    if (ctx.server_fd != -1) {
        close(ctx.server_fd);
        unlink(CONTROL_PATH);
    }
    if (ctx.monitor_fd != -1) close(ctx.monitor_fd);

    /* Final metadata heap cleanup */
    pthread_mutex_lock(&ctx.metadata_lock);
    container_record_t *curr = ctx.containers;
    while (curr) {
        container_record_t *tmp = curr;
        curr = curr->next;
        free(tmp);
    }
    ctx.containers = NULL;
    pthread_mutex_unlock(&ctx.metadata_lock);

    bounded_buffer_destroy(&ctx.log_buffer);
    pthread_mutex_destroy(&ctx.metadata_lock);
    return 0;
}

/*
 * Implement the client-side control request path.
 *
 * The CLI commands use a UNIX domain socket to communicate with the
 * supervisor.
 */
static int send_control_request(const control_request_t *req)
{
    int fd;
    struct sockaddr_un addr;
    control_response_t resp;

    fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return 1;
    }

    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, CONTROL_PATH, sizeof(addr.sun_path) - 1);

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect to supervisor (is it running?)");
        close(fd);
        return 1;
    }

    if (write(fd, req, sizeof(*req)) != sizeof(*req)) {
        perror("write request");
        close(fd);
        return 1;
    }

    if (read(fd, &resp, sizeof(resp)) != sizeof(resp)) {
        perror("read response");
        close(fd);
        return 1;
    }

    if (resp.status != 0) {
        fprintf(stderr, "Supervisor error: %s\n", resp.message);
        close(fd);
        return 1;
    }

    if (req->kind == CMD_PS || req->kind == CMD_LOGS) {
        printf("%s\n", resp.message);
    } else {
        printf("Success: %s\n", resp.message);
    }

    close(fd);
    return 0;
}

static int cmd_start(int argc, char *argv[])
{
    control_request_t req;

    if (argc < 5) {
        fprintf(stderr,
                "Usage: %s start <id> <container-rootfs> <command> [--soft-mib N] [--hard-mib N] [--nice N]\n",
                argv[0]);
        return 1;
    }

    memset(&req, 0, sizeof(req));
    req.kind = CMD_START;
    strncpy(req.container_id, argv[2], sizeof(req.container_id) - 1);
    strncpy(req.rootfs, argv[3], sizeof(req.rootfs) - 1);
    strncpy(req.command, argv[4], sizeof(req.command) - 1);
    req.soft_limit_bytes = DEFAULT_SOFT_LIMIT;
    req.hard_limit_bytes = DEFAULT_HARD_LIMIT;

    if (parse_optional_flags(&req, argc, argv, 5) != 0)
        return 1;

    return send_control_request(&req);
}

static int cmd_run(int argc, char *argv[])
{
    control_request_t req;

    if (argc < 5) {
        fprintf(stderr,
                "Usage: %s run <id> <container-rootfs> <command> [--soft-mib N] [--hard-mib N] [--nice N]\n",
                argv[0]);
        return 1;
    }

    memset(&req, 0, sizeof(req));
    req.kind = CMD_RUN;
    strncpy(req.container_id, argv[2], sizeof(req.container_id) - 1);
    strncpy(req.rootfs, argv[3], sizeof(req.rootfs) - 1);
    strncpy(req.command, argv[4], sizeof(req.command) - 1);
    req.soft_limit_bytes = DEFAULT_SOFT_LIMIT;
    req.hard_limit_bytes = DEFAULT_HARD_LIMIT;

    if (parse_optional_flags(&req, argc, argv, 5) != 0)
        return 1;

    return send_control_request(&req);
}

static int cmd_ps(void)
{
    control_request_t req;

    memset(&req, 0, sizeof(req));
    req.kind = CMD_PS;

    return send_control_request(&req);
}

static int cmd_logs(int argc, char *argv[])
{
    control_request_t req;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s logs <id>\n", argv[0]);
        return 1;
    }

    memset(&req, 0, sizeof(req));
    req.kind = CMD_LOGS;
    strncpy(req.container_id, argv[2], sizeof(req.container_id) - 1);

    return send_control_request(&req);
}

static int cmd_stop(int argc, char *argv[])
{
    control_request_t req;

    if (argc < 3) {
        fprintf(stderr, "Usage: %s stop <id>\n", argv[0]);
        return 1;
    }

    memset(&req, 0, sizeof(req));
    req.kind = CMD_STOP;
    strncpy(req.container_id, argv[2], sizeof(req.container_id) - 1);

    return send_control_request(&req);
}

int main(int argc, char *argv[])
{
    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "supervisor") == 0) {
        if (argc < 3) {
            fprintf(stderr, "Usage: %s supervisor <base-rootfs>\n", argv[0]);
            return 1;
        }
        return run_supervisor(argv[2]);
    }

    if (strcmp(argv[1], "start") == 0)
        return cmd_start(argc, argv);

    if (strcmp(argv[1], "run") == 0)
        return cmd_run(argc, argv);

    if (strcmp(argv[1], "ps") == 0)
        return cmd_ps();

    if (strcmp(argv[1], "logs") == 0)
        return cmd_logs(argc, argv);

    if (strcmp(argv[1], "stop") == 0)
        return cmd_stop(argc, argv);

    usage(argv[0]);
    return 1;
}
